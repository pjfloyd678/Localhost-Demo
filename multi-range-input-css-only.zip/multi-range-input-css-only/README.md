# Multi Range input, CSS-only 

A Pen created on CodePen.io. Original URL: [https://codepen.io/vsync/pen/mdEJMLv](https://codepen.io/vsync/pen/mdEJMLv).

range input slider with CSS ticks by using a wrapper with custom css properties (css variables) with min and max values printed at the edges

minimum value text is aligned to the left, and maximum value same, to the right.
the current value (output element) is always kept within the horizontal range of the component, so it won't overflow.

The demo assumes some sort of JS template will auto-generate the markup, so it's zero manual work filling out all the many CSS variables / HTML attributes.

This was used in my other component:
https://github.com/yairEO/color-picker
<?php
/**
 * This PHP page validates if a UPC code is valid.
 * Command Line arguments
 *  upccheck_simple.php "[UPC Code]"
 *  where:
 *      [UPC Code] = The UPC Code to check. (in Quotes)
 *  return: true or false (JSON)
 */
$upcCode = $argv[ 1 ];
$newCode = str_replace( ' ', '', $upcCode ); // remove spaces
$arrCode = str_split( $newCode, 1 ); // convert to an array
$oddCount = 0; $evenCount = 0; $checkDigit = (int) $arrCode[ 11 ]; // initialize totals
for ( $indx=0; $indx < strlen( $newCode ) - 1; $indx++ ) {
    $val = (int) $arrCode[ $indx ];
    $indx % 2 == 0 ? $oddCount += (int) $arrCode[ $indx ] : $evenCount += (int) $arrCode[ $indx ]; // count the values from the array
}
$check = ( $oddCount * 3 ) + $evenCount + $checkDigit;
echo ( $check % 10 == 0 ? json_encode( true ) : json_encode( false ) ); // divisible by 10?

<?php
/**
 * This PHP page validates if a UPC code is valid.
 * There are 2 ways to execute the script
 * 1. Command Line
 *      upccheck.php "[UPC Code]" [1]
 *      where:
 *          [UPC Code] = The UPC Code to check. (in Quotes)
 *          [debug] = If you would like a detailed response, use 1
 * 2. Website URL
 *      upccheck.php?upccode=[UPC Code]&debug=1
 *      where:
 *          [UPC Code] = The UPC Code to check. Please provide code without spaces or replaces spaces with "%20"
 *          [debug] = If you would like a detailed response, use 1
 * return: true or false (JSON)
*/

// Initialize detailed response array
$response = array(
    'code' => 0,
    'text' => "",
);
// if you would like the default response to provide a detailed information, set this value to true!
$debug = false;

// this allows the script to be used as a command line or web browser
if ( isset( $argv ) ) {
    if ( isset( $argv[ 1 ] ) ) {
        $upcCode = $argv[ 1 ];
    } else {
        if ( $debug ) {
            $response[ 'code' ] = 410;
            $response[ 'text' ] = "No Command Line Argument (UPC Code) provided.";
            echo json_encode( $response );
            die();
        }
        echo json_encode( false );
        die();
    }
    $debug = isset( $argv[ 2 ] ) ? boolval( $argv[ 2 ] ) : false;
} else {
    $upcCode = filter_input( INPUT_GET, 'upccode' );
    $d       = filter_input( INPUT_GET, 'debug' );
    if ( isset( $d ) && ( ! $debug ) ) {
            $debug = boolval( $d );
    }
}
// Check to see if UPC Code was provided
if ( empty( $upcCode ) ) {
    if ( $debug ) {
        $response[ 'code' ] = 411;
        $response[ 'text' ] = "No UPC Code provided.";
        echo json_encode( $response );
        die();
    }
    echo json_encode( false );
    die();
}
$newCode = str_replace( ' ', '', $upcCode ); // remove spaces
$newCode = str_replace( '%20', '', $newCode ); // remove %20(url spaces);

// Check length of code
if ( strlen( $newCode ) !== 12 ) {
    if ( $debug ) {
        $response[ 'code' ] = 412;
        $response[ 'text' ] = "Invalid UPC Code (L:" . strlen( $newCode ) . ")";
        echo json_encode( $response );
        die();
    }
    echo json_encode( false );
    die();
}
// Check if the code is numeric
if ( !is_numeric( $newCode ) ) {
    if ( $debug ) {
        $response[ 'code' ] = 413;
        $response[ 'text' ] = "Invalid UPC Code (Non-Numeric Value found)";
        echo json_encode( $response );
        die();
    }
    echo json_encode( false );
    die();
}

// UPC Code is good. Let's continue!
$arrCode = str_split( $newCode, 1 ); // convert to an array

//Initialize counters and the last check digit
$oddCount = 0;
$evenCount = 0;
$checkDigit = (int) $arrCode[ 11 ];

//Loop through and add up the values
for ( $indx=0; $indx < strlen( $newCode ) - 1; $indx++ ) {
    $val = (int) $arrCode[ $indx ];
    $indx % 2 == 0 ? $oddCount += $val : $evenCount += $val;
}
// add it all up
$check = ( $oddCount * 3 ) + $evenCount + $checkDigit;
// check if the number is divisible by 10
if ( $check % 10 !== 0 ) {
    // Error
    if ( $debug ) {
        $response[ 'code' ] = 414;
        $response[ 'text' ] = "Invalid UPC code ($check)";
        echo json_encode( $response );
        exit();
    }
    echo json_encode( false );
    exit();
}
// valid upc code
if ( $debug ) {
    $response[ 'code' ] = 200;
    $response[ 'text' ] = "Valid";
    echo json_encode( $response );
    exit();
}
echo json_encode( true );
exit();

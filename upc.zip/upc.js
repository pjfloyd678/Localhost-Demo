$(document).ready(function() {

    // Hide the success and error containers
    $( "#upccode" ).focus( function() {
        $( "#results_success_container").hide();
        $( "#results_error_container").hide();
    });
    
    // Proceed when the submit button is clicked.
    $( "#formSubmit" ).click( function( evt ) {
        evt.preventDefault();
        $( "#results_success_container").hide();
        $( "#results_error_container").hide();
        var upcCode = $( "#upccode" ).val(); // Get the value
        if ( upcCode !== '' ) { // check if there is a value
            var url = "upccheck.php?upccode=" + upcCode + "&debug=1"; 
            $.get( url, function( data ){ // API Call!
                var results = JSON.parse( data ); // Parse Data
                if ( results.code === 200 ) { // Check the code
                    $( "#results_success" ).html( "UPC Code is VALID!" );
                    $( "#results_success_container").show();
                } else {
                    $( "#results_error" ).html( results.text );
                    $( "#results_error_container").show();
                }
            });
        } else { // Error!
            $( "#results_error" ).html( "Please provide a UPC Code" );
            $( "#results_error_container").show();
        }
    });
});

<?PHP
?>
<html>
	<head>
		<title>Virtual Slots</title>
	</head>
	<body>
		<h4>Play a slot</h4>
		<div>[<a href="play.php">Default slot</a>]</div>
		<div>[<a href="play.php?slot=1">Slot 1</a>] (same as default if you have not made any changes) </div>
		<div>[<a href="play.php?slot=2">Slot 2</a>]</div>
		<div>[<a href="play.php?slot=3">Slot 3</a>]</div>
	</body>
</html>
